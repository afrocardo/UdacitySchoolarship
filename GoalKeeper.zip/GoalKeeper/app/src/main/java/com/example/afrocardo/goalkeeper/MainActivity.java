package com.example.afrocardo.goalkeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int faltasTeamA = 0;
    int faltasTeamB = 0;
    int resetScore = 0;
    int resetFaltas = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.team_a_score);
        quantityTextView.setText("" + number);
    }


    public void displayTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayFaltasA(int fA) {
        TextView faltasaView = (TextView) findViewById(R.id.faltas1);
        faltasaView.setText(String.valueOf(fA));
    }

    public void fA(View view) {
        faltasTeamA = faltasTeamA + 1;
        displayFaltasA(faltasTeamA);
    }


    public void gA(View view) {
        scoreTeamA = scoreTeamA + 1;
        displayTeamA(scoreTeamA);
    }


    public void displayTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));

    }

    public void displayFaltasB(int fB) {
        TextView faltasbView = (TextView) findViewById(R.id.faltas2);
        faltasbView.setText(String.valueOf(fB));
    }


    public void fB(View view) {
        faltasTeamB = faltasTeamB + 1;
        displayFaltasB(faltasTeamB);
    }


    public void gB(View view) {
        scoreTeamB = scoreTeamB + 1;
        displayTeamB(scoreTeamB);
    }


    public void resetAll(View view) {
        resetScore = scoreTeamA = 0;
        resetScore = scoreTeamB = 0;
        resetFaltas = faltasTeamA = 0;
        resetFaltas = faltasTeamB = 0;
        displayTeamA(resetScore);
        displayFaltasA(resetFaltas);
        displayTeamB(resetScore);
        displayFaltasB(resetFaltas);
    }

}